import { useEffect } from 'react';

export default function App() {
  useEffect(() => {
    console.log('[CEB] Example runtime content view loaded');
		console.log(document.body.outerHTML.replace(/<[^>]*>/g, '').trim());
  }, []);

  return <div className="ceb-example-runtime-content-view-text">Example runtime content view</div>;
}
